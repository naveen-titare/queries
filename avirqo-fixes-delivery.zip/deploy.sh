#!/bin/bash
# Deploy script - run from your project root (~/avirqo)

set -e

echo "📦 Deploying fixes to avirqo-backend and avirqo-frontend..."

# Backend
echo "🔧 Copying backend files..."
cp -r avirqo-backend/* ~/avirqo/avirqo-backend/

echo "🗄️ Running migrations..."
cd ~/avirqo/avirqo-backend
php artisan migrate

echo "🧹 Clearing caches..."
php artisan config:clear
php artisan route:clear
php artisan cache:clear

# Frontend
echo "🎨 Copying frontend files..."
cp -r avirqo-frontend/* ~/avirqo/avirqo-frontend/

echo "🏗️ Building frontend..."
cd ~/avirqo/avirqo-frontend
npm run build

echo "✅ Deployment complete!"
echo ""
echo "📋 Summary of changes:"
echo "  - Send Voucher: Success message shows correct counts"
echo "  - Send Voucher: Code verification via SHA256 hash"
echo "  - Customer: SPOCs marked inactive (not deleted)"
echo "  - Customer: OTP verification for SPOC changes"
echo "  - Customer: Only active SPOCs in order cart"
