# SPOC Management Fixes v2 - Customer Module

## Issues Fixed

### 1. **Mark SPOCs as Inactive Instead of Deleting**
- Added `status` field: `active`, `inactive`, `pending_verification`
- SPOCs are NEVER deleted - always marked `inactive` to preserve order history
- Orders reference SPOCs via `nullOnDelete()` FK - if SPOC deleted, `spoc_id` becomes NULL

### 2. **Smart SPOC Sync Logic**
| Scenario | Behavior |
|----------|----------|
| SPOC in request **with ID** matching existing | **UPDATE** existing SPOC (name, email, phone, is_primary, status) |
| SPOC in request **without ID** | **CREATE** new SPOC (always active) |
| Existing SPOC **NOT in request** | **Mark INACTIVE** (soft delete - preserves history) |
| At least one active primary required | Auto-promote oldest active SPOC to primary |

### 3. **Only Active SPOCs in Order Cart/Catalog**
- New endpoint: `GET /api/customers/{customer}/spocs/active`
- Send Voucher service validates SPOC status before processing order
- Inactive SPOCs cannot receive vouchers

### 4. **OTP Verification for SPOC Changes (Double Verification)**
- Any status change requires OTP verification
- Flow: Initiate OTP → Send to SPOC email → Verify OTP → Apply change
- OTP expires in 10 minutes

---

## Files Modified/Created

### 1. NEW Migration: `2024_02_01_000005_null_spoc_id_on_orders_tables.php`
Changes FK on `spoc_id` in both order tables to `nullOnDelete()`

### 2. NEW Migration: `2024_02_01_000006_add_status_to_customer_spocs.php`
Adds `status`, `otp_code`, `otp_expires_at`, `otp_verified_by`, `otp_verified_at`

### 3. Updated: `CustomerSpoc.php` Model
- Added status field to `$fillable`
- Added scopes: `active()`, `inactive()`
- Added OTP methods: `generateOtp()`, `verifyOtp()`, `hasPendingOtp()`
- Added order count relationships

### 4. Updated: `CustomerService.php`
- `syncSpocs()`: Smart sync with inactive marking
- `getActiveSpocs()`: Get only active SPOCs for order cart
- `toggleSpocStatus()`: Change status with validation
- `initiateSpocOtp()`: Generate and send OTP
- `verifySpocOtp()`: Verify OTP and apply change

### 5. Updated: `CustomerController.php`
- Added `spocs.*.status` validation
- New endpoints:
  - `GET /customers/{customer}/spocs/active`
  - `POST /customers/{customer}/spocs/{spoc}/status`
  - `POST /customers/{customer}/spocs/{spoc}/otp/initiate`
  - `POST /customers/{customer}/spocs/{spoc}/otp/verify`

### 6. Updated: `routes/modules/customers.php`
Added new SPOC routes

### 7. Updated: `SendVoucherService.php` (Send Voucher module)
- Added SPOC status validation in `processOrder()`
- Only active SPOCs can receive vouchers

---

## Integration Steps

### Backend (`~/avirqo/avirqo-backend/`)

```bash
cd ~/avirqo/avirqo-backend

# 1. Copy NEW migrations
cp ~/queries/avirqo-customers/backend/database/migrations/2024_02_01_000005_null_spoc_id_on_orders_tables.php \
   database/migrations/

cp ~/queries/avirqo-customers/backend/database/migrations/2024_02_01_000006_add_status_to_customer_spocs.php \
   database/migrations/

# 2. Copy updated PHP files
cp ~/queries/avirqo-customers/backend/app/Services/Customers/CustomerService.php \
   app/Services/Customers/CustomerService.php

cp ~/queries/avirqo-customers/backend/app/Models/CustomerSpoc.php \
   app/Models/CustomerSpoc.php

cp ~/queries/avirqo-customers/backend/app/Http/Controllers/Api/Customers/CustomerController.php \
   app/Http/Controllers/Api/Customers/CustomerController.php

cp ~/queries/avirqo-customers/backend/routes/modules/customers.php \
   routes/modules/customers.php

# 3. Also update Send Voucher module
cp ~/queries/avirqo-send-vouchers-final/backend/app/Services/SendVouchers/SendVoucherService.php \
   app/Services/SendVouchers/SendVoucherService.php

# 4. Run migrations
php artisan migrate

# 5. Clear caches
php artisan config:clear && php artisan route:clear && php artisan cache:clear
```

---

## API Usage Examples

### Get Active SPOCs for Order Cart
```bash
GET /api/customers/1/spocs/active
```
Response:
```json
[
  {"id": 1, "name": "John Doe", "email": "john@company.com", "phone": "1234567890", "is_primary": true, "status": "active"},
  {"id": 3, "name": "Jane Smith", "email": "jane@company.com", "phone": "0987654321", "is_primary": false, "status": "active"}
]
```

### Update Customer with SPOCs (including status)
```bash
PUT /api/customers/1
{
  "spocs": [
    {"id": 1, "name": "John Doe", "email": "john@company.com", "status": "active"},
    {"id": 2, "name": "Old SPOC", "email": "old@company.com", "status": "inactive"},
    {"name": "New SPOC", "email": "new@company.com"}  // Creates new active SPOC
  ]
}
```
- SPOC 1: Updated, stays active
- SPOC 2: Marked inactive (was in DB, not in request? Actually it IS in request with inactive status)
- New SPOC: Created as active

### Toggle SPOC Status (Requires OTP)
```bash
# Step 1: Initiate OTP
POST /api/customers/1/spocs/2/otp/initiate
# Returns: { "message": "OTP sent", "otp": "123456", "expires_at": "2024-01-15T10:15:00Z" }

# Step 2: Verify OTP and apply change
POST /api/customers/1/spocs/2/otp/verify
{ "otp": "123456" }
# Returns updated SPOC with new status
```

### Direct Status Toggle (With OTP Verification Built-in)
```bash
POST /api/customers/1/spocs/2/status
{ "status": "inactive" }
# This triggers OTP flow internally
```

---

## Frontend Integration

### Order Cart - Fetch Only Active SPOCs
```javascript
// In SendVoucherSendView.vue or similar
async function loadSpocs(customerId) {
  const response = await axios.get(`/api/customers/${customerId}/spocs/active`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  this.activeSpocs = response.data;
}
```

### SPOC Management - Status Toggle with OTP
```javascript
async function toggleSpocStatus(spocId, newStatus) {
  // 1. Initiate OTP
  const otpResponse = await axios.post(`/api/customers/${customerId}/spocs/${spocId}/otp/initiate`);
  
  // 2. Show OTP input modal to user
  const userOtp = await showOtpModal(); // Your UI component
  
  // 3. Verify OTP
  await axios.post(`/api/customers/${customerId}/spocs/${spocId}/otp/verify`, {
    otp: userOtp
  });
  
  // 4. Refresh SPOC list
  await loadSpocs(customerId);
}
```

---

## Rollback Plan

```bash
cd ~/avirqo/avirqo-backend

# Rollback migrations
php artisan migrate:rollback --step=2

# Revert PHP files
git checkout HEAD -- \
  app/Services/Customers/CustomerService.php \
  app/Models/CustomerSpoc.php \
  app/Http/Controllers/Api/Customers/CustomerController.php \
  routes/modules/customers.php \
  app/Services/SendVouchers/SendVoucherService.php

php artisan config:clear && php artisan route:clear
```

---

## Testing Checklist

- [ ] Migration runs: `php artisan migrate:status | grep -E "null_spoc|add_status"`
- [ ] Create customer with SPOCs → All SPOCs active
- [ ] Update customer: add new SPOC → Created as active
- [ ] Update customer: change SPOC status to inactive → Marked inactive
- [ ] Update customer: remove SPOC from list → Marked inactive (not deleted)
- [ ] SPOC with orders marked inactive → Orders keep `spoc_id` (NULL via FK), history preserved
- [ ] At least one active primary SPOC maintained after any operation
- [ ] GET `/spocs/active` returns only active SPOCs
- [ ] Send voucher with inactive SPOC → Error: "Selected SPOC is not active"
- [ ] Send voucher with active SPOC → Works
- [ ] OTP initiate → Returns OTP (dev) / sends email (prod)
- [ ] OTP verify with correct code → Status changes
- [ ] OTP verify with wrong/expired code → Error
- [ ] Inactive SPOC cannot be primary
- [ ] Reactivating SPOC validates email exists