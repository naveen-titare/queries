<template>
  <div class="avq-app">
    <!-- Global Loader Overlay -->
    <div 
      v-if="isLoading" 
      class="global-loader-overlay"
      :class="{ 'with-progress': showProgress }"
    >
      <div class="global-loader-content">
        <div class="spinner-ring">
          <div class="spinner-inner"></div>
        </div>
        
        <div v-if="loadingText" class="loader-text">{{ loadingText }}</div>
        
        <div v-if="showProgress" class="progress-bar-container">
          <div class="progress-bar" :style="{ width: progress + '%' }"></div>
        </div>
      </div>
    </div>

    <aside class="avq-sidebar">
      <div class="avq-sidebar-logo">avirq<span>o</span></div>
      <nav class="avq-sidebar-nav">
        <RouterLink class="avq-nav-item" to="/dashboard" active-class="active">
          <span class="avq-nav-icon">🏠</span> Dashboard
        </RouterLink>
        <RouterLink class="avq-nav-item" to="/customers" active-class="active">
          <span class="avq-nav-icon">🏢</span> Customers
        </RouterLink>
        <RouterLink class="avq-nav-item" to="/vouchers" active-class="active">
          <span class="avq-nav-icon">🎁</span> Vouchers
        </RouterLink>
        <RouterLink class="avq-nav-item" to="/send-vouchers" active-class="active">
        <span class="avq-nav-icon">📨</span> Send Vouchers
        </RouterLink>
        <a class="avq-nav-item" href="#"><span class="avq-nav-icon">📊</span> Reports</a>
        <a class="avq-nav-item" href="#"><span class="avq-nav-icon">⚙️</span> Settings</a>
      </nav>
      <button class="avq-sidebar-logout" @click="handleLogout">↩ Log out</button>
    </aside>
    <div class="avq-main">
      <header class="avq-topbar">
        <input class="avq-search" type="text" placeholder="Search…" />
        <div class="avq-topbar-right">
          <span class="avq-bell">🔔</span>
          <span class="avq-avatar">{{ initials }}</span>
        </div>
      </header>
      <slot />
    </div>
    <SessionReauthModal />
  </div>
</template>
<script setup>
import { computed } from 'vue'
import { RouterLink, useRouter } from 'vue-router'
import { useAuthStore } from '../../auth/store/authStore'
import SessionReauthModal from '../../auth/components/SessionReauthModal.vue'
import { useGlobalLoaderStore } from './GlobalLoaderStore'

const auth = useAuthStore()
const router = useRouter()
const { isLoading, loadingText, showProgress, progress, startLoading, stopLoading } = useGlobalLoaderStore()

const initials = computed(() => {
  const name = auth.user?.name || '?'
  return name.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase()
})
async function handleLogout() {
  await auth.logout()
  router.push('/login')
}
</script>
<style>
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,600&family=DM+Sans:wght@400;500;600;700&display=swap');
.avq-app {
  --teal-deep: #085041; --teal-mid: #1D9E75; --teal-light: #9FE1CB;
  --teal-pale: #E8F7F2; --ink: #0D0D0C; --ink-soft: #3A3A38;
  --ink-muted: #6B6A67; --ink-faint: #B4B2A9; --surface-2: #F7FAF9;
  --border-2: #E4EDE9; --fd: 'Fraunces', Georgia, serif;
  --fb: 'DM Sans', system-ui, sans-serif;
  display: flex; min-height: 100vh; background: var(--surface-2);
  font-family: var(--fb); color: var(--ink);
}
.avq-sidebar {
  width: 220px; flex-shrink: 0; background: var(--teal-deep); color: #fff;
  display: flex; flex-direction: column; padding: 24px 16px;
  position: sticky; top: 0; height: 100vh; overflow-y: auto;
}
.avq-sidebar-logo { font-weight: 700; font-size: 20px; letter-spacing: -0.04em; margin-bottom: 32px; padding-left: 8px; }
.avq-sidebar-logo span { color: var(--teal-light); }
.avq-sidebar-nav { display: flex; flex-direction: column; gap: 4px; flex: 1; }
.avq-nav-item { display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 8px; color: rgba(255,255,255,0.75); text-decoration: none; font-size: 14px; font-weight: 500; transition: background 0.15s ease; }
.avq-nav-item:hover { background: rgba(255,255,255,0.08); }
.avq-nav-item.active { background: rgba(255,255,255,0.14); color: #fff; font-weight: 600; }
.avq-sidebar-logout { background: rgba(255,255,255,0.1); color: #fff; border: none; border-radius: 8px; padding: 10px 12px; font-size: 13px; font-weight: 600; cursor: pointer; transition: background 0.15s ease; text-align: left; }
.avq-sidebar-logout:hover { background: rgba(255,255,255,0.18); }
.avq-main { flex: 1; display: flex; flex-direction: column; min-width: 0; }
.avq-topbar { height: 64px; background: #fff; border-bottom: 1px solid var(--border-2); display: flex; align-items: center; justify-content: space-between; padding: 0 28px; position: sticky; top: 0; z-index: 10; }
.avq-search { border: 1px solid var(--border-2); border-radius: 8px; padding: 9px 14px; font-size: 13px; width: 240px; outline: none; font-family: var(--fb); }
.avq-search:focus { border-color: var(--teal-mid); }
.avq-topbar-right { display: flex; align-items: center; gap: 16px; }
.avq-bell { font-size: 16px; }
.avq-avatar { width: 32px; height: 32px; border-radius: 50%; background: var(--teal-deep); color: #fff; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 700; }

/* Global Loader Styles */
.global-loader-overlay {
  position: fixed;
  inset: 0;
  background: rgba(8, 8, 12, 0.65);
  backdrop-filter: blur(4px);
  z-index: 99999;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px;
  animation: fadeIn 0.2s ease-out;
}

@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

.global-loader-content {
  background: #fff;
  border-radius: 16px;
  padding: 40px 48px;
  text-align: center;
  min-width: 280px;
  max-width: 90vw;
  box-shadow: 0 24px 64px rgba(8, 8, 12, 0.3);
  animation: slideUp 0.3s cubic-bezier(0.16, 1, 0.3, 1);
}

@keyframes slideUp {
  from { 
    opacity: 0; 
    transform: translateY(16px) scale(0.96); 
  }
  to { 
    opacity: 1; 
    transform: translateY(0) scale(1); 
  }
}

.spinner-ring {
  width: 56px;
  height: 56px;
  margin: 0 auto 20px;
  position: relative;
}

.spinner-ring::before,
.spinner-ring::after {
  content: '';
  position: absolute;
  inset: 0;
  border: 3px solid transparent;
  border-radius: 50%;
  animation: spinRing 1.2s cubic-bezier(0.4, 0, 0.2, 1) infinite;
}

.spinner-ring::before {
  border-top-color: var(--teal-deep, #1d9e75);
  border-right-color: var(--teal-deep, #1d9e75);
}

.spinner-ring::after {
  animation-direction: reverse;
  animation-duration: 0.8s;
  border-bottom-color: var(--teal-mid, #2eb886);
  border-left-color: var(--teal-mid, #2eb886);
}

@keyframes spinRing {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

.loader-text {
  font-size: 15px;
  color: var(--ink, #1a1a1a);
  font-weight: 500;
  margin-bottom: 16px;
  font-family: var(--fb, system-ui);
}

.progress-bar-container {
  width: 100%;
  height: 4px;
  background: var(--surface-2, #e8e8e8);
  border-radius: 2px;
  overflow: hidden;
}

.progress-bar {
  height: 100%;
  background: linear-gradient(90deg, var(--teal-deep, #1d9e75), var(--teal-mid, #2eb886));
  border-radius: 2px;
  transition: width 0.3s ease-out;
  width: 0%;
}

@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

@keyframes slideUp {
  from { 
    opacity: 0; 
    transform: translateY(16px) scale(0.96); 
  }
  to { 
    opacity: 1; 
    transform: translateY(0) scale(1); 
  }
}

.spinner-ring::before,
.spinner-ring::after {
  content: '';
  position: absolute;
  inset: 0;
  border: 3px solid transparent;
  border-radius: 50%;
  animation: spinRing 1.2s cubic-bezier(0.4, 0, 0.2, 1) infinite;
}

.spinner-ring::before {
  border-top-color: var(--teal-deep, #1d9e75);
  border-right-color: var(--teal-deep, #1d9e75);
}

.spinner-ring::after {
  animation-direction: reverse;
  animation-duration: 0.8s;
  border-bottom-color: var(--teal-mid, #2eb886);
  border-left-color: var(--teal-mid, #2eb886);
}

@keyframes spinRing {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

.loader-text {
  font-size: 15px;
  color: var(--ink, #1a1a1a);
  font-weight: 500;
  margin-bottom: 16px;
  font-family: var(--fb, system-ui);
}

.progress-bar-container {
  width: 100%;
  height: 4px;
  background: var(--surface-2, #e8e8e8);
  border-radius: 2px;
  overflow: hidden;
}

.progress-bar {
  height: 100%;
  background: linear-gradient(90deg, var(--teal-deep, #1d9e75), var(--teal-mid, #2eb886));
  border-radius: 2px;
  transition: width 0.3s ease-out;
  width: 0%;
}
</style>