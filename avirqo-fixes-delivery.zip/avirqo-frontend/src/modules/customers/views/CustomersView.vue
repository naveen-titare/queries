<template>
  <AppLayout>
  <div class="avq-customers">
    <!-- Header -->
    <div class="cust-header">
      <div>
        <h2>Customers</h2>
        <p>B2B clients purchasing vouchers from Avirqo</p>
      </div>
      <button class="avq-btn-primary" @click="openCreate">+ Add Customer</button>
    </div>

    <!-- Filters -->
    <div class="cust-filters">
      <input v-model="search" class="avq-input" placeholder="Search company or GST…" @input="loadList" />
      <select v-model="statusFilter" class="avq-input" @change="loadList">
        <option value="">All statuses</option>
        <option value="active">Active</option>
        <option value="on_hold">On Hold</option>
        <option value="inactive">Inactive</option>
      </select>
    </div>

    <!-- Table -->
    <div class="cust-table-wrap">
      <div v-if="store.loading" class="cust-empty">Loading…</div>
      <div v-else-if="store.error" class="cust-empty err">{{ store.error }}</div>
      <table v-else class="cust-table">
        <thead>
          <tr>
            <th>Company</th>
            <th>Location</th>
            <th>Primary SPOC</th>
            <th>Balance</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-if="store.list.length === 0">
            <td colspan="6" style="text-align:center;padding:32px;color:var(--ink-muted)">No customers yet.</td>
          </tr>
          <tr v-for="c in store.list" :key="c.id" @click="openDetail(c.id)" class="cust-row">
            <td class="cust-name">{{ c.company_name }}</td>
            <td>{{ c.location }}</td>
            <td>{{ primarySpoc(c) }}</td>
            <td class="cust-balance">₹{{ Number(c.balance).toLocaleString('en-IN') }}</td>
            <td><span class="cust-badge" :class="`badge-${c.status}`">{{ statusLabel(c.status) }}</span></td>
            <td @click.stop>
              <div class="cust-actions">
                <button class="avq-btn-sm" @click="openEdit(c.id)">Edit</button>
                <select class="avq-input-sm" :value="c.status" @change="changeStatus(c, $event.target.value)">
                  <option value="active">Active</option>
                  <option value="on_hold">On Hold</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Pagination -->
    <div v-if="store.pagination" class="cust-pagination">
      <button :disabled="store.pagination.current_page === 1" @click="changePage(store.pagination.current_page - 1)">← Prev</button>
      <span>Page {{ store.pagination.current_page }} of {{ store.pagination.last_page }}</span>
      <button :disabled="store.pagination.current_page === store.pagination.last_page" @click="changePage(store.pagination.current_page + 1)">Next →</button>
    </div>

    <!-- Create/Edit Modal -->
    <div v-if="showForm" class="avq-modal-overlay" @click.self="showForm = false">
      <div class="avq-modal">
        <h3>{{ editId ? 'Edit Customer' : 'Add Customer' }}</h3>
        <form @submit.prevent="submitForm">
          <div class="form-grid">
            <div class="form-field">
              <label>Company Name *</label>
              <input v-model="form.company_name" class="avq-input" required />
            </div>
            <div class="form-field">
              <label>Location *</label>
              <input v-model="form.location" class="avq-input" required />
            </div>
            <div class="form-field">
              <label>GST Number</label>
              <input v-model="form.gst_number" class="avq-input" />
            </div>
            <div class="form-field">
              <label>Registration Number</label>
              <input v-model="form.registration_number" class="avq-input" />
            </div>
          </div>

          <div class="spoc-section">
            <div class="spoc-head">
              <h4>SPOCs (Contacts)</h4>
              <button type="button" class="avq-btn-sm" @click="addSpoc">+ Add SPOC</button>
            </div>
            
            <!-- EXISTING SPOCs (from database) -->
            <template v-if="editId && existingSpocs.length">
              <div class="spoc-subsection">
                <h5 class="spoc-subtitle">Existing SPOCs</h5>
                <div v-for="(spoc, idx) in existingSpocs" :key="spoc.id" class="spoc-row existing-spoc">
                  <input v-model="spoc.name" class="avq-input" placeholder="Name *" required />
                  <input v-model="spoc.email" class="avq-input" type="email" placeholder="Email *" required />
                  <input v-model="spoc.phone" class="avq-input" placeholder="Phone" />
                  
                  <!-- Status Select -->
                  <select v-model="spoc.status" class="avq-input" style="width:140px">
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                  
                  <!-- Primary Badge & Toggle -->
                  <div class="spoc-primary-cell" style="display:flex; align-items:center; gap:8px; min-width:120px">
                    <span v-if="spoc.is_primary" class="spoc-primary">Primary</span>
                    <button 
                      v-else 
                      type="button" 
                      class="avq-btn-sm" 
                      style="padding:4px 10px; font-size:11px"
                      @click="makePrimary(spoc)"
                      :disabled="spoc.status !== 'active'"
                    >Set Primary</button>
                  </div>
                  
                  <!-- Edit/Delete Actions -->
                  <div class="spoc-actions" style="display:flex; gap:6px; align-items:center">
                    <button 
                      type="button" 
                      class="avq-btn-sm btn-danger" 
                      @click="removeExistingSpoc(spoc)"
                      :disabled="spoc.is_primary"
                      :title="spoc.is_primary ? 'Primary SPOC cannot be removed. Set another as primary first.' : ''"
                    >✕</button>
                  </div>
                </div>
              </div>
            </template>

            <!-- NEW SPOCs (being added) -->
            <div class="spoc-subsection" v-if="newSpocs.length">
              <h5 class="spoc-subtitle">New SPOCs</h5>
              <div v-for="(spoc, i) in newSpocs" :key="i" class="spoc-row new-spoc">
                <input v-model="spoc.name" class="avq-input" placeholder="Name *" required />
                <input v-model="spoc.email" class="avq-input" type="email" placeholder="Email *" required />
                <input v-model="spoc.phone" class="avq-input" placeholder="Phone" />
                <button type="button" class="avq-btn-sm btn-danger" @click="removeNewSpoc(i)">✕</button>
              </div>
            </div>

            <!-- Add New SPOC Button -->
            <div class="spoc-add-row" style="margin-top:8px">
              <button type="button" class="avq-btn-sm" @click="addSpoc" style="width:100%; justify-content:center">
                + Add New SPOC
              </button>
            </div>
          </div>

          <div v-if="editId" class="doc-upload-note">
            📎 To upload business documents, save this form first then click the customer row to open the detail panel — documents can be attached there.
          </div>
          <div v-else class="doc-upload-note">
            📎 Business documents can be uploaded after the customer is created — click the customer row to open the detail panel.
          </div>

          <p v-if="formError" class="form-error">{{ formError }}</p>
          <div class="modal-footer">
            <button type="button" class="avq-btn-ghost" @click="showForm = false">Cancel</button>
            <button type="submit" class="avq-btn-primary" :disabled="formLoading">
              {{ formLoading ? 'Saving…' : (editId ? 'Save changes' : 'Create customer') }}
            </button>
          </div>
        </form>
      </div>
    </div>

    <!-- Detail Drawer -->
    <div v-if="showDetail" class="avq-modal-overlay" @click.self="showDetail = false">
      <div class="avq-drawer">
        <div v-if="store.loading" style="padding:32px">Loading…</div>
        <template v-else-if="store.current">
          <div class="drawer-header">
            <div>
              <h3>{{ store.current.company_name }}</h3>
              <span class="cust-badge" :class="`badge-${store.current.status}`">{{ statusLabel(store.current.status) }}</span>
            </div>
            <button class="avq-btn-ghost" @click="showDetail = false">✕ Close</button>
          </div>

          <!-- Company Details -->
          <div class="drawer-section">
            <h4>Company Details</h4>
            <div class="detail-grid">
              <div class="detail-item"><span class="detail-label">Company Name</span><span class="detail-value">{{ store.current.company_name }}</span></div>
              <div class="detail-item"><span class="detail-label">Location</span><span class="detail-value">{{ store.current.location }}</span></div>
              <div class="detail-item"><span class="detail-label">GST Number</span><span class="detail-value">{{ store.current.gst_number || '—' }}</span></div>
              <div class="detail-item"><span class="detail-label">Registration No.</span><span class="detail-value">{{ store.current.registration_number || '—' }}</span></div>
              <div class="detail-item"><span class="detail-label">Customer Since</span><span class="detail-value">{{ new Date(store.current.created_at).toLocaleDateString('en-IN') }}</span></div>
            </div>
            <button class="avq-btn-sm" style="margin-top:12px" @click="showDetail=false; openEdit(store.current.id)">✏️ Edit Details</button>
          </div>

          <!-- Balance -->
          <div class="drawer-section">
            <h4>Balance</h4>
            <div class="balance-display">₹{{ Number(store.current.balance).toLocaleString('en-IN') }}</div>
            <div class="balance-actions">
              <button class="avq-btn-primary" @click="openBalance('credit')">+ Add Balance</button>
              <button class="avq-btn-ghost" @click="openBalance('debit')">− Deduct Balance</button>
            </div>
          </div>

          <!-- SPOCs (Only Active) -->
          <div class="drawer-section">
            <h4>SPOCs (Active Only)</h4>
            <div v-if="activeSpocs.length === 0" class="cust-empty">No active SPOCs.</div>
            <div v-for="spoc in activeSpocs" :key="spoc.id" class="spoc-card">
              <strong>{{ spoc.name }}</strong>
              <span v-if="spoc.is_primary" class="spoc-primary">Primary</span>
              <div class="spoc-detail">{{ spoc.email }}</div>
              <div v-if="spoc.phone" class="spoc-detail">{{ spoc.phone }}</div>
              <span class="spoc-status-badge" :class="`badge-${spoc.status}`">{{ spoc.status }}</span>
            </div>
          </div>

          <!-- Documents -->
          <div class="drawer-section">
            <div class="section-head">
              <h4>Documents</h4>
              <label class="avq-btn-sm" style="cursor:pointer">
                📎 Attach file
                <input type="file" style="display:none" @change="handleFileSelect" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png" />
              </label>
            </div>

            <!-- Pending file confirmation -->
            <div v-if="pendingFile" class="doc-pending">
              <span class="doc-name">{{ pendingFile.name }}</span>
              <span class="doc-size">{{ formatSize(pendingFile.size) }}</span>
              <button class="avq-btn-primary avq-btn-sm-p" :disabled="uploadLoading" @click="confirmUpload">
                {{ uploadLoading ? 'Uploading…' : '↑ Upload' }}
              </button>
              <button class="avq-btn-sm btn-danger" @click="cancelUpload">✕ Cancel</button>
            </div>

            <div v-if="!store.current.documents?.length && !pendingFile" class="cust-empty">No documents uploaded.</div>
            <div v-for="doc in store.current.documents" :key="doc.id" class="doc-row">
              <span class="doc-name">{{ doc.original_name }}</span>
              <span class="doc-size">{{ formatSize(doc.size) }}</span>
              <button class="avq-btn-sm" @click="downloadDoc(doc)">↓ Download</button>
              <button class="avq-btn-sm btn-danger" @click="confirmDeleteDoc(doc)">✕</button>
            </div>
          </div>

          <!-- Balance Logs -->
          <div class="drawer-section">
            <h4>Balance History</h4>
            <div v-if="!store.current.balance_logs?.length" class="cust-empty">No transactions yet.</div>
            <table v-else class="log-table">
              <thead><tr><th>Type</th><th>Amount</th><th>Balance After</th><th>Note</th><th>By</th><th>Date</th></tr></thead>
              <tbody>
                <tr v-for="log in store.current.balance_logs" :key="log.id">
                  <td><span :class="log.type === 'credit' ? 'log-credit' : 'log-debit'">{{ log.type }}</span></td>
                  <td>₹{{ Number(log.amount).toLocaleString('en-IN') }}</td>
                  <td>₹{{ Number(log.balance_after).toLocaleString('en-IN') }}</td>
                  <td>{{ log.note || '—' }}</td>
                  <td>{{ log.done_by?.name || '—' }}</td>
                  <td>{{ new Date(log.created_at).toLocaleDateString('en-IN') }}</td>
                </tr>
              </tbody>
            </table>
          </div>

          <!-- Voucher History -->
          <div class="drawer-section">
            <h4>Voucher History</h4>
            <div v-if="!store.current.voucher_history?.length" class="cust-empty">No vouchers issued yet.</div>
            <table v-else class="log-table">
              <thead><tr><th>Voucher</th><th>Denomination</th><th>Qty</th><th>Total Deducted</th><th>Sent By</th><th>Date</th></tr></thead>
              <tbody>
                <tr v-for="v in store.current.voucher_history" :key="v.id">
                  <td>{{ v.voucher_name }}</td>
                  <td>₹{{ Number(v.denomination).toLocaleString('en-IN') }}</td>
                  <td>{{ v.quantity }}</td>
                  <td>₹{{ Number(v.total_deducted).toLocaleString('en-IN') }}</td>
                  <td>{{ v.sent_by?.name || '—' }}</td>
                  <td>{{ new Date(v.sent_at).toLocaleDateString('en-IN') }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </template>
      </div>
    </div>

    <!-- Balance Modal -->
    <div v-if="showBalance" class="avq-modal-overlay" @click.self="showBalance = false">
      <div class="avq-modal avq-modal-sm">
        <h3>{{ balanceType === 'credit' ? 'Add Balance' : 'Deduct Balance' }}</h3>
        <div class="form-field">
          <label>Amount (₹) *</label>
          <input v-model="balanceAmount" class="avq-input" type="number" min="0.01" step="0.01" required />
        </div>
        <div class="form-field">
          <label>Note</label>
          <input v-model="balanceNote" class="avq-input" placeholder="Optional reason" />
        </div>
        <p v-if="balanceError" class="form-error">{{ balanceError }}</p>
        <div class="modal-footer">
          <button class="avq-btn-ghost" @click="showBalance = false">Cancel</button>
          <button class="avq-btn-primary" :disabled="balanceLoading" @click="submitBalance">
            {{ balanceLoading ? 'Saving…' : 'Confirm' }}
          </button>
        </div>
      </div>
    </div>
  </div>
  </AppLayout>
</template>

<script setup>
import { ref, reactive, onMounted, computed } from 'vue';
import { useCustomerStore } from '../store/customerStore';
import customerApi from '../api/customerApi';
import AppLayout from '../../shared/components/AppLayout.vue';
import { useGlobalLoaderStore } from '../../shared/components/GlobalLoaderStore';

const store = useCustomerStore();
const search = ref('');
const statusFilter = ref('');
const page = ref(1);

// Global loader
const { startLoading, stopLoading } = useGlobalLoaderStore();

const showForm = ref(false);
const editId = ref(null);
const formLoading = ref(false);
const formError = ref('');

// Form state
const form = reactive({ 
  company_name: '', 
  location: '', 
  gst_number: '', 
  registration_number: '', 
  spocs: [{ name: '', email: '', phone: '' }] 
});

// Computed: Separate existing SPOCs (with ID) from new SPOCs (without ID)
const existingSpocs = computed(() => form.spocs.filter(s => s.id));
const newSpocs = computed(() => form.spocs.filter(s => !s.id));

const showDetail = ref(false);
const showBalance = ref(false);
const balanceType = ref('credit');
const balanceAmount = ref('');
const balanceNote = ref('');
const balanceLoading = ref(false);
const balanceError = ref('');

// Detail view: Only active SPOCs
const activeSpocs = computed(() => 
  store.current?.spocs?.filter(s => s.status === 'active') || []
);

onMounted(() => loadList());

async function loadList() { 
  startLoading("Loading customers...");
  try {
    await store.fetchList({ search: search.value, status: statusFilter.value, page: page.value });
  } finally {
    stopLoading();
  }
}
function changePage(p) { page.value = p; loadList(); }

function primarySpoc(c) { return c.spocs?.find((s) => s.is_primary)?.name || c.spocs?.[0]?.name || '—'; }
function statusLabel(s) { return { active: 'Active', on_hold: 'On Hold', inactive: 'Inactive' }[s] || s; }

function openCreate() {
  editId.value = null;
  Object.assign(form, { 
    company_name: '', 
    location: '', 
    gst_number: '', 
    registration_number: '', 
    spocs: [{ name: '', email: '', phone: '' }] 
  });
  formError.value = '';
  showForm.value = true;
}

async function openEdit(id) {
  startLoading("Loading customer...");
  try {
    await store.fetchOne(id);
    editId.value = id;
    const c = store.current;
    Object.assign(form, {
      company_name: c.company_name, 
      location: c.location,
      gst_number: c.gst_number || '', 
      registration_number: c.registration_number || '',
      spocs: c.spocs?.length ? c.spocs.map((s) => ({ 
        id: s.id,
        name: s.name, 
        email: s.email, 
        phone: s.phone || '',
        status: s.status || 'active',
        is_primary: s.is_primary || false
      })) : [{ name: '', email: '', phone: '' }],
    });
    formError.value = '';
    showForm.value = true;
  } finally {
    stopLoading();
  }
}

function addSpoc() { 
  form.spocs.push({ name: '', email: '', phone: '' }); 
}

function removeSpoc(i) { 
  form.spocs.splice(i, 1); 
}

function removeNewSpoc(i) {
  const idx = form.spocs.findIndex(s => !s.id);
  if (idx >= 0) form.spocs.splice(idx, 1);
}

function removeExistingSpoc(spoc) {
  if (spoc.is_primary) {
    formError.value = 'Primary SPOC cannot be removed. Set another as primary first.';
    return;
  }
  form.spocs = form.spocs.filter(s => s.id !== spoc.id);
}

function makePrimary(spoc) {
  if (spoc.status !== 'active') {
    formError.value = 'Only active SPOCs can be set as primary.';
    return;
  }
  // Remove primary from all others
  form.spocs.forEach(s => { s.is_primary = false; });
  // Set this as primary
  spoc.is_primary = true;
}

async function submitForm() {
  formLoading.value = true;
  formError.value = '';
  
  // Validation: At least one active SPOC required
  const activeCount = form.spocs.filter(s => s.status === 'active').length;
  if (activeCount === 0) {
    formError.value = 'At least one active SPOC is required.';
    formLoading.value = false;
    return;
  }
  
  // Validation: Must have a primary SPOC
  const hasPrimary = form.spocs.some(s => s.is_primary && s.status === 'active');
  if (!hasPrimary) {
    formError.value = 'An active primary SPOC is required.';
    formLoading.value = false;
    return;
  }

  try {
    // Prepare payload - include id for existing SPOCs
    const payload = {
      company_name: form.company_name,
      location: form.location,
      gst_number: form.gst_number || null,
      registration_number: form.registration_number || null,
      spocs: form.spocs.map(s => ({
        id: s.id || undefined,
        name: s.name,
        email: s.email,
        phone: s.phone || null,
        status: s.status || 'active',
        is_primary: s.is_primary || false
      }))
    };

    if (editId.value) {
      await store.update(editId.value, payload);
    } else {
      await store.create(payload);
    }
    showForm.value = false;
    loadList();
  } catch (e) {
    const errs = e.response?.data?.errors;
    formError.value = errs ? Object.values(errs).flat().join(' ') : (e.response?.data?.message || 'Save failed.');
  } finally {
    formLoading.value = false;
  }
}

async function openDetail(id) {
  startLoading("Loading customer details...");
  try {
    showDetail.value = true;
    await store.fetchOne(id);
  } finally {
    stopLoading();
  }
}

async function changeStatus(customer, status) {
  startLoading("Updating status...");
  try {
    await store.setStatus(customer.id, status);
  } finally {
    stopLoading();
  }
}

function openBalance(type) {
  balanceType.value = type;
  balanceAmount.value = '';
  balanceNote.value = '';
  balanceError.value = '';
  showBalance.value = true;
}

async function submitBalance() {
  balanceLoading.value = true;
  balanceError.value = '';
  try {
    await store.adjustBalance(store.current.id, {
      type: balanceType.value,
      amount: parseFloat(balanceAmount.value),
      note: balanceNote.value,
    });
    showBalance.value = false;
  } catch (e) {
    balanceError.value = e.response?.data?.message || 'Failed.';
  } finally {
    balanceLoading.value = false;
  }
}

const pendingFile = ref(null);
const uploadLoading = ref(false);

function handleFileSelect(e) {
  const file = e.target.files[0];
  if (!file) return;
  pendingFile.value = file;
  e.target.value = '';
}

function cancelUpload() { pendingFile.value = null; }

async function confirmUpload() {
  if (!pendingFile.value) return;
  startLoading("Uploading document...");
  uploadLoading.value = true;
  try {
    await store.uploadDocument(store.current.id, pendingFile.value);
    pendingFile.value = null;
  } catch (e) {
    alert(e.response?.data?.message || 'Upload failed.');
  } finally {
    uploadLoading.value = false;
    stopLoading();
  }
}

async function confirmDeleteDoc(doc) {
  if (!confirm(`Delete "${doc.original_name}"?`)) return;
  startLoading("Deleting document...");
  try {
    await store.deleteDocument(store.current.id, doc.id);
  } finally {
    stopLoading();
  }
}

async function downloadDoc(doc) {
  try {
    const token = localStorage.getItem('avirqo_access_token');
    const url = customerApi.downloadUrl(store.current.id, doc.id);
    const response = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!response.ok) throw new Error('Download failed');
    const blob = await response.blob();
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = doc.original_name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);
  } catch (e) {
    alert('Could not download the file. Please try again.');
  }
}

function formatSize(bytes) {
  if (!bytes) return '';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1048576).toFixed(1)} MB`;
}
</script>
