# Integration Steps for Fixed Send Voucher Feature

## Overview
This document provides step-by-step instructions to integrate the fixes for:
1. **Issue 1**: Success message not showing actual brand count and voucher code count
2. **Issue 2**: No way to validate if codes in Excel match database

---

## Files Modified

### Backend (Laravel)
| File | Change Type | Description |
|------|-------------|-------------|
| `database/migrations/2024_03_01_000004_add_codes_hash_to_send_voucher_orders_table.php` | **NEW** | Migration to add `codes_hash` column |
| `app/Models/SendVoucherOrder.php` | Modified | Added `codes_hash` to `$fillable` |
| `app/Services/SendVouchers/SendVoucherService.php` | Modified | Added hash computation, verification methods, Excel verification sheet |
| `app/Http/Controllers/Api/SendVouchers/SendVoucherController.php` | Modified | Added `verifyOrder` endpoint |
| `routes/modules/send-vouchers.php` | Modified | Added verification route |

### Frontend (Vue 3 + Pinia)
| File | Change Type | Description |
|------|-------------|-------------|
| `src/modules/send-vouchers/views/SendVoucherConfirmView.vue` | Modified | Fixed success message to use saved cart data; displays verification hash |

---

## Backend Integration Steps

### 1. Run the New Migration
```bash
cd ~/avirqo/avirqo-backend
php artisan migrate
```
This adds the `codes_hash` column to `send_voucher_orders` table.

### 2. Clear Caches
```bash
php artisan config:clear
php artisan route:clear
php artisan cache:clear
```

### 3. Verify New API Endpoint
The new verification endpoint is available at:
```
POST /api/send-vouchers/orders/{id}/verify
```

**Request Body (optional):**
```json
{
  "code_ids": [1, 2, 3, 4, 5]
}
```
If `code_ids` is not provided, it fetches all sent codes for that order automatically.

**Response:**
```json
{
  "order_id": 123,
  "order_number": "AVQ-SEND-2026-00001",
  "stored_hash": "a1b2c3d4e5f6...",
  "computed_hash": "a1b2c3d4e5f6...",
  "matches": true,
  "total_codes": 5,
  "codes": [
    {"code_id": 1, "product_name": "Amazon", "brand": "Amazon", "denomination": 500, "status": "sent"},
    ...
  ],
  "provided_codes_match": true,
  "provided_code_ids": [1, 2, 3, 4, 5]
}
```

---

## Frontend Integration Steps

### 1. Copy Updated Frontend File
```bash
# From the fixed repo to your project
cp ~/queries/avirqo-send-vouchers-final/frontend/src/modules/send-vouchers/views/SendVoucherConfirmView.vue \
   ~/avirqo/avirqo-frontend/src/modules/send-vouchers/views/SendVoucherConfirmView.vue
```

### 2. Rebuild Frontend
```bash
cd ~/avirqo/avirqo-frontend
npm run build
# or if using dev server
npm run dev
```

---

## Testing the Fixes

### Test Issue 1 Fix: Success Message Shows Correct Counts
1. Go to `/send-vouchers` catalog
2. Add items to cart (e.g., 1 brand, 2 codes)
3. Proceed to Confirm & Send
4. Select customer and SPOC
5. Click "Confirm & Send"
6. **Verify**: Success overlay shows:
   - "2 codes across 1 brand worth ₹X sent to email@domain.com"
   - Order number displayed
   - Verification hash displayed

### Test Issue 2 Fix: Code Verification
#### Option A: Via Excel (Manual)
1. Open the Excel attachment sent via email
2. Go to "Vouchers" sheet → Unhide column H ("Code ID (for verification)")
3. Copy the Code IDs
4. Go to "Verification" sheet for instructions and hash

#### Option B: Via API (Automated)
```bash
# Get order ID from order history or success message
curl -X POST "http://your-api/api/send-vouchers/orders/123/verify" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"code_ids": [1,2,3,4,5]}'
```

**Expected Response:**
- `"matches": true` → Codes in Excel match database ✓
- `"matches": false` → Mismatch detected ✗

#### Option C: Via Order Detail API
```bash
curl -X GET "http://your-api/api/send-vouchers/orders/123" \
  -H "Authorization: Bearer YOUR_TOKEN"
```
Response now includes `codes_hash` field and `items.codes` relation.

---

## How Verification Works

### Hash Computation
```php
// In SendVoucherService::computeCodesHash()
$codeIds = [1, 5, 3, 2, 4];  // Unsorted
sort($codeIds);              // [1, 2, 3, 4, 5]
$hash = hash('sha256', '1,2,3,4,5');  // Deterministic
```

### Why This Works
1. **Deterministic**: Same code IDs always produce same hash
2. **Order-independent**: Sorting ensures consistent hash regardless of query order
3. **Tamper-evident**: Any code change (add/remove/modify) changes the hash
4. **No sensitive data**: Hash is of code IDs, not the actual voucher codes

### Verification Flow
```
┌─────────────┐     ┌──────────────┐     ┌─────────────────┐
│  Database   │────▶│  Send Email  │────▶│   Excel File    │
│  (codes)    │     │  (with hash) │     │  (with Code IDs)│
└─────────────┘     └──────────────┘     └────────┬────────┘
                                                   │
                              ┌────────────────────┘
                              ▼
                     ┌──────────────────┐
                     │  Verification    │
                     │  API Endpoint    │
                     │  (recompute &    │
                     │   compare hash)  │
                     └────────┬─────────┘
                              │
                     ┌────────▼────────┐
                     │ matches: true/  │
                     │ false           │
                     └─────────────────┘
```

---

## Rollback Plan
If issues arise:
```bash
# Backend: Rollback migration
php artisan migrate:rollback --step=1

# Frontend: Revert file
git checkout HEAD -- src/modules/send-vouchers/views/SendVoucherConfirmView.vue
npm run build
```

---

## Configuration Options

### Email Attachment Size Limit
In `config/send-vouchers.php` (create if not exists):
```php
return [
    'max_codes_per_email' => 5000,
    'max_attachment_mb' => 18,
];
```

### Verification Hash Algorithm
Currently uses SHA256. To change, modify `computeCodesHash()` in `SendVoucherService.php`.

---

## Support
For issues, check:
1. Laravel logs: `storage/logs/laravel.log`
2. Browser console for frontend errors
3. API response in Network tab